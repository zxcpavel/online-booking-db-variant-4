<?php
require_once __DIR__ . '/AbstractRepository.php';

class AppointmentRepository extends AbstractRepository {
    public function __construct(PDO $pdo) {
        parent::__construct($pdo, 'lessons', 'lesson_id');
    }
    
    // 🔹 Получение свободных слотов для преподавателя на дату
    public function getAvailableSlots(int $teacherId, string $date, int $durationMinutes): array {
        // Рабочие часы: 9:00 - 20:00, шаг 30 минут
        $workingStart = 9 * 60;   // 540 минут от полуночи
        $workingEnd = 20 * 60;    // 1200 минут
        $step = 30;               // шаг слота в минутах
        
        // Получаем занятые слоты на эту дату у этого преподавателя
        $sql = "SELECT lesson_datetime, duration_minutes FROM lessons 
                WHERE teacher_id = ? AND DATE(lesson_datetime) = ? AND status != 'отменено'";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$teacherId, $date]);
        $booked = $stmt->fetchAll();
        
        // Формируем массив занятых интервалов [start_minutes, end_minutes]
        $busyIntervals = [];
        foreach ($booked as $b) {
            $start = (int)date('H', strtotime($b['lesson_datetime'])) * 60 + 
                     (int)date('i', strtotime($b['lesson_datetime']));
            $end = $start + (int)$b['duration_minutes'];
            $busyIntervals[] = [$start, $end];
        }
        
        // Генерируем все возможные слоты и фильтруем занятые
        $slots = [];
        for ($time = $workingStart; $time + $durationMinutes <= $workingEnd; $time += $step) {
            $slotEnd = $time + $durationMinutes;
            $isFree = true;
            
            foreach ($busyIntervals as [$busyStart, $busyEnd]) {
                // Проверка пересечения интервалов
                if ($time < $busyEnd && $slotEnd > $busyStart) {
                    $isFree = false;
                    break;
                }
            }
            
            if ($isFree) {
                $slots[] = [
                    'time' => sprintf('%02d:%02d', intdiv($time, 60), $time % 60),
                    'datetime' => "$date " . sprintf('%02d:%02d:00', intdiv($time, 60), $time % 60)
                ];
            }
        }
        
        return $slots;
    }
    
    // 🔹 Создание записи с проверкой конкуренции (optimistic locking)
    public function createAppointment(array $data): int {
        $this->pdo->beginTransaction();
        try {
            // 🔥 ПОВТОРНАЯ ПРОВЕРКА: слот всё ещё свободен?
            $check = $this->pdo->prepare("SELECT COUNT(*) FROM lessons 
                                          WHERE teacher_id = ? AND lesson_datetime = ? 
                                          AND status != 'отменено'");
            $check->execute([$data['teacher_id'], $data['lesson_datetime']]);
            if ($check->fetchColumn() > 0) {
                throw new Exception("Выбранное время только что занято. Пожалуйста, выберите другое.");
            }
            
            // Проверка: ученик не записан на этот инструмент дважды в день
            $check2 = $this->pdo->prepare("SELECT COUNT(*) FROM lessons 
                                           WHERE student_id = ? AND instrument_id = ? 
                                           AND DATE(lesson_datetime) = DATE(?) AND status != 'отменено'");
            $check2->execute([$data['student_id'], $data['instrument_id'], $data['lesson_datetime']]);
            if ($check2->fetchColumn() > 0) {
                throw new Exception("Ученик уже записан на этот инструмент в этот день.");
            }
            
            // Вставка
            $sql = "INSERT INTO lessons (student_id, teacher_id, instrument_id, lesson_datetime, duration_minutes, status) 
                    VALUES (?, ?, ?, ?, ?, 'запланировано')";
            $this->pdo->prepare($sql)->execute([
                $data['student_id'],
                $data['teacher_id'],
                $data['instrument_id'],
                $data['lesson_datetime'],
                $data['duration_minutes']
            ]);
            
            $this->pdo->commit();
            return (int)$this->pdo->lastInsertId();
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
    
    // 🔹 Список записей с фильтрами
    public function findAllWithFilters(array $filters = []): array {
        $sql = "SELECT l.*, 
                       CONCAT(s.last_name, ' ', s.first_name) as student_name,
                       CONCAT(t.last_name, ' ', t.first_name) as teacher_name,
                       i.instrument_name
                FROM lessons l
                JOIN students s ON l.student_id = s.student_id
                JOIN teachers t ON l.teacher_id = t.teacher_id
                JOIN instruments i ON l.instrument_id = i.instrument_id
                WHERE 1=1";
        $params = [];
        
        // Фильтры
        if (!empty($filters['date_from'])) {
            $sql .= " AND DATE(l.lesson_datetime) >= ?";
            $params[] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $sql .= " AND DATE(l.lesson_datetime) <= ?";
            $params[] = $filters['date_to'];
        }
        if (!empty($filters['teacher_id'])) {
            $sql .= " AND l.teacher_id = ?";
            $params[] = $filters['teacher_id'];
        }
        if (!empty($filters['status'])) {
            $sql .= " AND l.status = ?";
            $params[] = $filters['status'];
        }
        if (!empty($filters['student_search'])) {
            $sql .= " AND (s.last_name LIKE ? OR s.first_name LIKE ?)";
            $params[] = "%{$filters['student_search']}%";
            $params[] = "%{$filters['student_search']}%";
        }
        
        $sql .= " ORDER BY l.lesson_datetime DESC LIMIT 50";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    // 🔹 Изменение статуса с проверкой допустимости
    public function changeStatus(int $appointmentId, string $newStatus): bool {
        $allowedTransitions = [
            'запланировано' => ['подтверждено', 'отменено'],
            'подтверждено' => ['начато', 'отменено'],
            'начато' => ['завершено'],
            'отменено' => [],
            'завершено' => []
        ];
        
        $current = $this->findById($appointmentId);
        if (!$current) return false;
        
        $currentStatus = $current['status'];
        if (!in_array($newStatus, $allowedTransitions[$currentStatus] ?? [])) {
            throw new Exception("Недопустимый переход статуса: $currentStatus → $newStatus");
        }
        
        $sql = "UPDATE lessons SET status = ? WHERE lesson_id = ?";
        return $this->pdo->prepare($sql)->execute([$newStatus, $appointmentId]);
    }
    
    // 🔹 Перенос записи на новое время
    public function reschedule(int $appointmentId, string $newDatetime): bool {
        $this->pdo->beginTransaction();
        try {
            // Проверка: новое время свободно
            $current = $this->findById($appointmentId);
            if (!$current) throw new Exception("Запись не найдена");
            
            $check = $this->pdo->prepare("SELECT COUNT(*) FROM lessons 
                                          WHERE teacher_id = ? AND lesson_datetime = ? 
                                          AND lesson_id != ? AND status != 'отменено'");
            $check->execute([$current['teacher_id'], $newDatetime, $appointmentId]);
            if ($check->fetchColumn() > 0) {
                throw new Exception("Новое время уже занято.");
            }
            
            $sql = "UPDATE lessons SET lesson_datetime = ? WHERE lesson_id = ?";
            $this->pdo->prepare($sql)->execute([$newDatetime, $appointmentId]);
            
            $this->pdo->commit();
            return true;
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
    
    // 🔹 Статистика для отчётов
    public function getStatsByDate(string $yearMonth): array {
        $sql = "SELECT DATE(lesson_datetime) as date, COUNT(*) as count, 
                       SUM(CASE WHEN status = 'завершено' THEN 1 ELSE 0 END) as completed
                FROM lessons 
                WHERE DATE_FORMAT(lesson_datetime, '%Y-%m') = ?
                GROUP BY DATE(lesson_datetime)
                ORDER BY date";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$yearMonth]);
        return $stmt->fetchAll();
    }
    
    public function getTeacherLoad(string $dateFrom, string $dateTo): array {
        $sql = "SELECT t.teacher_id, CONCAT(t.last_name, ' ', t.first_name) as teacher_name,
                       COUNT(l.lesson_id) as total_lessons,
                       SUM(l.duration_minutes) as total_minutes
                FROM teachers t
                LEFT JOIN lessons l ON t.teacher_id = l.teacher_id 
                    AND l.lesson_datetime BETWEEN ? AND ?
                    AND l.status != 'отменено'
                GROUP BY t.teacher_id
                ORDER BY total_lessons DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$dateFrom, $dateTo]);
        return $stmt->fetchAll();
    }
    
    // 🔹 Экспорт в CSV
    public function exportToCsv(array $appointments): string {
        $output = fopen('php://memory', 'w');
        fputcsv($output, ['ID', 'Дата', 'Ученик', 'Преподаватель', 'Инструмент', 'Длительность', 'Статус'], ';');
        
        foreach ($appointments as $a) {
            fputcsv($output, [
                $a['lesson_id'],
                $a['lesson_datetime'],
                $a['student_name'],
                $a['teacher_name'],
                $a['instrument_name'],
                $a['duration_minutes'],
                $a['status']
            ], ';');
        }
        
        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);
        return $csv;
    }
}