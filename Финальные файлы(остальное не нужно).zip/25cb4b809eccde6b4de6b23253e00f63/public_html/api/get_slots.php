<?php
require_once __DIR__ . '/../src/Database.php';
require_once __DIR__ . '/../src/AppointmentRepository.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$teacherId = (int)($_GET['teacher_id'] ?? 0);
$date = $_GET['date'] ?? '';
$duration = (int)($_GET['duration'] ?? 60);

if (!$teacherId || !$date || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid parameters']);
    exit;
}

try {
    $pdo = Database::getConnection();
    $repo = new AppointmentRepository($pdo);
    $slots = $repo->getAvailableSlots($teacherId, $date, $duration);
    echo json_encode(['success' => true, 'slots' => $slots]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}