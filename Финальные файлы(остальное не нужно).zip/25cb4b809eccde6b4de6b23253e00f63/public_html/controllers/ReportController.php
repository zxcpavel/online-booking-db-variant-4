<?php
class ReportController extends BaseController {
    private AppointmentRepository $apptRepo;
    
    public function __construct(PDO $pdo) {
        parent::__construct($pdo);
        $this->apptRepo = new AppointmentRepository($pdo);
    }
    
    public function index(): void {
        $this->render('report/index');
    }
    
    public function byDate(): void {
        $yearMonth = $_GET['month'] ?? date('Y-m');
        $stats = $this->apptRepo->getStatsByDate($yearMonth);
        
        $this->render('report/by_date', [
            'stats' => $stats,
            'currentMonth' => $yearMonth
        ]);
    }
    
    public function teacherLoad(): void {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-01');
        $dateTo = $_GET['date_to'] ?? date('Y-m-t');
        $load = $this->apptRepo->getTeacherLoad($dateFrom, $dateTo);
        
        $this->render('report/teacher_load', [
            'load' => $load,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo
        ]);
    }
    
    public function exportCsv(): void {
        $filters = [
            'date_from' => $_GET['date_from'] ?? date('Y-m-01'),
            'date_to' => $_GET['date_to'] ?? date('Y-m-t')
        ];
        
        $appointments = $this->apptRepo->findAllWithFilters($filters);
        $csv = $this->apptRepo->exportToCsv($appointments);
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=appointments_' . date('Y-m-d') . '.csv');
        echo $csv;
        exit;
    }
}