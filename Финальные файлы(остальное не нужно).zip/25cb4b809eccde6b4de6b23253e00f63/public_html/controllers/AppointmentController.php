<?php
require_once __DIR__ . '/../src/AppointmentRepository.php';
require_once __DIR__ . '/../src/Validator.php';

class AppointmentController extends BaseController {
    private AppointmentRepository $repo;
    
    public function __construct(PDO $pdo) {
        parent::__construct($pdo);
        $this->repo = new AppointmentRepository($pdo);
    }
    
    public function create(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // AJAX или обычная отправка
            $isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
                      strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
            
            if (!Validator::checkCsrfToken($_POST['csrf_token'] ?? '')) {
                $this->jsonResponse(['error' => 'CSRF token invalid'], $isAjax ? 403 : 302, $isAjax);
                return;
            }
            
            // Валидация
            $errors = [];
            if (empty($_POST['student_id'])) $errors['student_id'] = 'Выберите ученика';
            if (empty($_POST['teacher_id'])) $errors['teacher_id'] = 'Выберите преподавателя';
            if (empty($_POST['instrument_id'])) $errors['instrument_id'] = 'Выберите инструмент';
            if (empty($_POST['lesson_datetime'])) $errors['lesson_datetime'] = 'Выберите время';
            
            // Проверка: дата не в прошлом
            if (!empty($_POST['lesson_datetime']) && strtotime($_POST['lesson_datetime']) < time()) {
                $errors['lesson_datetime'] = 'Нельзя записаться в прошлое';
            }
            
            if ($errors) {
                if ($isAjax) {
                    $this->jsonResponse(['error' => implode('; ', array_values($errors))], 400, true);
                } else {
                    $this->render('appointment/create', ['errors' => $errors, 'old' => $_POST]);
                }
                return;
            }
            
            try {
                $appointmentId = $this->repo->createAppointment([
                    'student_id' => (int)$_POST['student_id'],
                    'teacher_id' => (int)$_POST['teacher_id'],
                    'instrument_id' => (int)$_POST['instrument_id'],
                    'lesson_datetime' => $_POST['lesson_datetime'],
                    'duration_minutes' => (int)($_POST['duration_minutes'] ?? 60)
                ]);
                
                $bookingCode = substr(md5($appointmentId . time()), 0, 8);
                
                if ($isAjax) {
                    $this->jsonResponse([
                        'success' => true,
                        'appointment_id' => $appointmentId,
                        'booking_code' => $bookingCode
                    ], 200, true);
                } else {
                    Validator::setFlash('success', "Запись создана! Код: $bookingCode");
                    $this->redirect('index.php', ['entity' => 'appointment', 'action' => 'view', 'id' => $appointmentId]);
                }
            } catch (Exception $e) {
                if ($isAjax) {
                    $this->jsonResponse(['error' => $e->getMessage()], 409, true);
                } else {
                    Validator::setFlash('error', $e->getMessage());
                    $this->render('appointment/create', ['old' => $_POST]);
                }
            }
        } else {
            // GET: показать форму
            $students = (new StudentRepository($this->pdo))->findAll();
            $instruments = (new InstrumentRepository($this->pdo))->findAll();
            $this->render('appointment/create', [
                'students' => $students,
                'instruments' => $instruments,
                'csrf' => Validator::generateCsrfToken()
            ]);
        }
    }
    
    public function list(): void {
        $filters = [
            'date_from' => $_GET['date_from'] ?? date('Y-m-d'),
            'date_to' => $_GET['date_to'] ?? date('Y-m-d', strtotime('+7 days')),
            'teacher_id' => $_GET['teacher_id'] ?? null,
            'status' => $_GET['status'] ?? null,
            'student_search' => $_GET['student_search'] ?? null
        ];
        
        $appointments = $this->repo->findAllWithFilters($filters);
        $teachers = (new TeacherRepository($this->pdo))->findAll();
        
        $this->render('appointment/list', [
            'appointments' => $appointments,
            'teachers' => $teachers,
            'filters' => $filters
        ]);
    }
    
    public function view(int $id): void {
        $appointment = $this->repo->getAppointmentDetails($id); // нужно добавить метод
        if (!$appointment) {
            Validator::setFlash('error', 'Запись не найдена');
            $this->redirect('index.php', ['entity' => 'appointment']);
        }
        
        $this->render('appointment/view', ['appointment' => $appointment]);
    }
    
    public function changeStatus(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php', ['entity' => 'appointment']);
        }
        
        $id = (int)($_POST['appointment_id'] ?? 0);
        $newStatus = $_POST['status'] ?? '';
        
        if (!Validator::checkCsrfToken($_POST['csrf_token'] ?? '')) {
            Validator::setFlash('error', 'Ошибка CSRF');
            $this->redirect('index.php', ['entity' => 'appointment']);
        }
        
        try {
            $this->repo->changeStatus($id, $newStatus);
            Validator::setFlash('success', "Статус обновлён: $newStatus");
        } catch (Exception $e) {
            Validator::setFlash('error', $e->getMessage());
        }
        
        $this->redirect('index.php', ['entity' => 'appointment', 'action' => 'view', 'id' => $id]);
    }
    
    public function reschedule(int $id): void {
        $appointment = $this->repo->findById($id);
        if (!$appointment) {
            Validator::setFlash('error', 'Запись не найдена');
            $this->redirect('index.php', ['entity' => 'appointment']);
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $newDatetime = $_POST['new_datetime'] ?? '';
            
            if (!Validator::checkCsrfToken($_POST['csrf_token'] ?? '')) {
                Validator::setFlash('error', 'Ошибка CSRF');
                $this->redirect('index.php', ['entity' => 'appointment', 'action' => 'view', 'id' => $id]);
            }
            
            try {
                $this->repo->reschedule($id, $newDatetime);
                Validator::setFlash('success', 'Запись перенесена');
                $this->redirect('index.php', ['entity' => 'appointment', 'action' => 'view', 'id' => $id]);
            } catch (Exception $e) {
                Validator::setFlash('error', $e->getMessage());
                $this->render('appointment/view', ['appointment' => $appointment, 'reschedule_error' => $e->getMessage()]);
            }
        } else {
            $this->render('appointment/view', ['appointment' => $appointment]);
        }
    }
    
    // 🔹 Вспомогательный метод для JSON-ответов
    private function jsonResponse(array $data, int $code = 200, bool $isAjax = true): void {
        if ($isAjax) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code($code);
            echo json_encode($data, JSON_UNESCAPED_UNICODE);
            exit;
        } else {
            if ($code === 302 && !empty($data['redirect'])) {
                header("Location: {$data['redirect']}");
                exit;
            }
            Validator::setFlash($data['error'] ? 'error' : 'success', $data['error'] ?? $data['message'] ?? '');
            $this->redirect('index.php', ['entity' => 'appointment']);
        }
    }
}