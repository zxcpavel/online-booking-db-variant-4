<?php
class StudentRepository extends AbstractRepository {
    public function __construct(PDO $pdo) { parent::__construct($pdo, 'students', 'student_id'); }
}
// В конце класса StudentRepository
public function findAllPaginated(int $limit, int $offset, array $search = []): array {
    $sql = "SELECT * FROM students";
    $params = [];
    
    if ($search) {
        $conditions = [];
        foreach ($search as $col => $val) {
            $conditions[] = "$col LIKE ?";
            $params[] = $val;
        }
        $sql .= " WHERE " . implode(' OR ', $conditions);
    }
    
    $sql .= " ORDER BY last_name LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $this->pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

public function count(array $search = []): int {
    $sql = "SELECT COUNT(*) FROM students";
    $params = [];
    
    if ($search) {
        $conditions = [];
        foreach ($search as $col => $val) {
            $conditions[] = "$col LIKE ?";
            $params[] = $val;
        }
        $sql .= " WHERE " . implode(' OR ', $conditions);
    }
    
    return (int)$this->pdo->query($sql)->fetchColumn();
}

public function hasRelatedLessons(int $studentId): bool {
    $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM lessons WHERE student_id = ?");
    $stmt->execute([$studentId]);
    return $stmt->fetchColumn() > 0;
}

public function getLessonsCount(int $studentId): int {
    $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM lessons WHERE student_id = ?");
    $stmt->execute([$studentId]);
    return (int)$stmt->fetchColumn();
}