<?php
class Validator {
    public static function validateStudent(array $data, bool $isUpdate = false): array {
        $errors = [];
        
        // Фамилия и имя
        if (empty(trim($data['last_name'] ?? ''))) $errors['last_name'] = 'Фамилия обязательна';
        if (empty(trim($data['first_name'] ?? ''))) $errors['first_name'] = 'Имя обязательно';
        
        // Телефон: формат +7...
        $phone = $data['phone'] ?? '';
        if (!preg_match('/^\+7\d{10}$/', preg_replace('/[^\d+]/', '', $phone))) {
            $errors['phone'] = 'Телефон в формате +79123456789';
        }
        
        // Email
        if (!filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Некорректный email';
        }
        
        // Дата рождения: не в будущем, возраст >= 5 лет
        $birth = $data['birth_date'] ?? '';
        if ($birth) {
            $birthDate = new DateTime($birth);
            $today = new DateTime();
            $minAge = new DateTime('-5 years');
            if ($birthDate > $today) $errors['birth_date'] = 'Дата не может быть в будущем';
            if ($birthDate > $minAge) $errors['birth_date'] = 'Минимальный возраст — 5 лет';
        }
        
        // При обновлении: проверка уникальности телефона/email (исключая текущую запись)
        if ($isUpdate && empty($errors)) {
            // Проверка делается в репозитории, здесь только структура
        }
        
        return $errors;
    }
    
    public static function generateCsrfToken(): string {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    public static function checkCsrfToken(string $token): bool {
        if (session_status() === PHP_SESSION_NONE) session_start();
        return hash_equals($_SESSION['csrf_token'] ?? '', $token);
    }
    
    public static function setFlash(string $type, string $message): void {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION['flash'] = ['type' => $type, 'message' => $message];
    }
    
    public static function getFlash(): ?array {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        return $flash;
    }
}