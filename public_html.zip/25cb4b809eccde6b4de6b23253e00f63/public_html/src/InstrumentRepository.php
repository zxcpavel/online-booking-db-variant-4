<?php
require_once __DIR__ . '/AbstractRepository.php';

class InstrumentRepository extends AbstractRepository {
    public function __construct(PDO $pdo) {
        parent::__construct($pdo, 'instruments', 'instrument_id');
    }
    
    // 🔹 Пагинация + поиск
    public function findAllPaginated(int $limit, int $offset, array $search = []): array {
        $sql = "SELECT i.*, COUNT(DISTINCT ti.teacher_id) as teachers_count 
                FROM instruments i
                LEFT JOIN teacher_instruments ti ON i.instrument_id = ti.instrument_id";
        $params = [];
        
        if ($search) {
            $conditions = [];
            foreach ($search as $col => $val) {
                $conditions[] = "i.$col LIKE ?";
                $params[] = $val;
            }
            $sql .= " WHERE " . implode(' OR ', $conditions);
        }
        
        $sql .= " GROUP BY i.instrument_id ORDER BY i.instrument_name LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    // 🔹 Подсчёт для пагинации
    public function count(array $search = []): int {
        $sql = "SELECT COUNT(*) FROM instruments";
        $params = [];
        
        if ($search) {
            $conditions = [];
            foreach ($search as $col => $val) {
                $conditions[] = "$col LIKE ?";
                $params[] = $val;
            }
            $sql .= " WHERE " . implode(' OR ', $conditions);
        }
        
        return (int)$this->pdo->query($sql)->fetchColumn();
    }
    
    // 🔹 Проверка связей: используется ли инструмент в уроках?
    public function hasRelatedLessons(int $instrumentId): bool {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM lessons WHERE instrument_id = ?");
        $stmt->execute([$instrumentId]);
        return $stmt->fetchColumn() > 0;
    }
    
    // 🔹 Количество уроков с этим инструментом
    public function getLessonsCount(int $instrumentId): int {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM lessons WHERE instrument_id = ?");
        $stmt->execute([$instrumentId]);
        return (int)$stmt->fetchColumn();
    }
    
    // 🔹 Получить преподавателей, ведущих этот инструмент
    public function getTeachers(int $instrumentId): array {
        $sql = "SELECT t.* FROM teachers t
                JOIN teacher_instruments ti ON t.teacher_id = ti.teacher_id
                WHERE ti.instrument_id = ?
                ORDER BY t.last_name";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$instrumentId]);
        return $stmt->fetchAll();
    }
    
    // 🔹 Проверка уникальности названия
    public function isNameUnique(string $name, ?int $excludeId = null): bool {
        $sql = "SELECT COUNT(*) FROM instruments WHERE instrument_name = ?";
        $params = [$name];
        
        if ($excludeId !== null) {
            $sql .= " AND instrument_id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchColumn() == 0;
    }
}