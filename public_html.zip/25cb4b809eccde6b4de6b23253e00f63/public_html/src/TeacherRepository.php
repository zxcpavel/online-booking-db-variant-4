<?php
require_once __DIR__ . '/AbstractRepository.php';

class TeacherRepository extends AbstractRepository {
    public function __construct(PDO $pdo) {
        parent::__construct($pdo, 'teachers', 'teacher_id');
    }
    
    // 🔹 Пагинация + поиск
    public function findAllPaginated(int $limit, int $offset, array $search = []): array {
        $sql = "SELECT t.*, COUNT(DISTINCT ti.instrument_id) as instruments_count 
                FROM teachers t
                LEFT JOIN teacher_instruments ti ON t.teacher_id = ti.teacher_id";
        $params = [];
        
        if ($search) {
            $conditions = [];
            foreach ($search as $col => $val) {
                $conditions[] = "t.$col LIKE ?";
                $params[] = $val;
            }
            $sql .= " WHERE " . implode(' OR ', $conditions);
        }
        
        $sql .= " GROUP BY t.teacher_id ORDER BY t.last_name LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    // 🔹 Подсчёт для пагинации
    public function count(array $search = []): int {
        $sql = "SELECT COUNT(DISTINCT t.teacher_id) FROM teachers t";
        $params = [];
        
        if ($search) {
            $conditions = [];
            foreach ($search as $col => $val) {
                $conditions[] = "$col LIKE ?";
                $params[] = $val;
            }
            $sql .= " WHERE " . implode(' OR ', $conditions);
        }
        
        return (int)$this->pdo->query($sql)->fetchColumn();
    }
    
    // 🔹 Проверка связей: есть ли уроки у преподавателя?
    public function hasRelatedLessons(int $teacherId): bool {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM lessons WHERE teacher_id = ?");
        $stmt->execute([$teacherId]);
        return $stmt->fetchColumn() > 0;
    }
    
    // 🔹 Количество уроков преподавателя
    public function getLessonsCount(int $teacherId): int {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM lessons WHERE teacher_id = ?");
        $stmt->execute([$teacherId]);
        return (int)$stmt->fetchColumn();
    }
    
    // 🔹 Получить инструменты, которые ведёт преподаватель
    public function getInstruments(int $teacherId): array {
        $sql = "SELECT i.* FROM instruments i
                JOIN teacher_instruments ti ON i.instrument_id = ti.instrument_id
                WHERE ti.teacher_id = ?
                ORDER BY i.instrument_name";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$teacherId]);
        return $stmt->fetchAll();
    }
    
    // 🔹 Добавить инструмент преподавателю
    public function addInstrument(int $teacherId, int $instrumentId): bool {
        try {
            $sql = "INSERT INTO teacher_instruments (teacher_id, instrument_id) VALUES (?, ?)";
            $this->pdo->prepare($sql)->execute([$teacherId, $instrumentId]);
            return true;
        } catch (PDOException $e) {
            return false; // Дубликат или ошибка
        }
    }
    
    // 🔹 Удалить инструмент у преподавателя
    public function removeInstrument(int $teacherId, int $instrumentId): bool {
        $sql = "DELETE FROM teacher_instruments WHERE teacher_id = ? AND instrument_id = ?";
        $this->pdo->prepare($sql)->execute([$teacherId, $instrumentId]);
        return true;
    }
}