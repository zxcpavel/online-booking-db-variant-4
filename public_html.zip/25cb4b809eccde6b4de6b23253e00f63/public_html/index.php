<?php
require_once 'src/Database.php';
require_once 'controllers/BaseController.php';

$pdo = Database::getConnection();
$entity = $_GET['entity'] ?? 'student';
$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? null;

// Простая маршрутизация
$controllers = [
    'student' => 'StudentController',
    'teacher' => 'TeacherController',
    'instrument' => 'InstrumentController'
];

if (!isset($controllers[$entity])) {
    die('Сущность не найдена');
}

require_once "controllers/{$controllers[$entity]}.php";
$controller = new $controllers[$entity]($pdo);

switch ($action) {
    case 'list': $controller->list(); break;
    case 'create': $controller->create(); break;
    case 'edit': $controller->edit((int)$id); break;
    case 'delete': $controller->delete((int)$id); break;
    case 'view': $controller->view((int)$id); break; // 🔹 для партнёра
    default: $controller->list();
}