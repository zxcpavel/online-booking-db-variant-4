<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>🎵 Музыкальная школа — Панель управления</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="public/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">🎼 Музыкальная школа</a>
            <div class="navbar-nav">
                <a class="nav-link" href="?entity=student">Ученики</a>
                <a class="nav-link" href="?entity=teacher">Преподаватели</a>
                <a class="nav-link" href="?entity=instrument">Инструменты</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <?php require __DIR__ . '/partials/flash.php'; ?>
        <?php require __DIR__ . '/partials/errors.php'; ?>
        <?= $content ?? '' ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="public/js/validation.js"></script>
</body>
</html>