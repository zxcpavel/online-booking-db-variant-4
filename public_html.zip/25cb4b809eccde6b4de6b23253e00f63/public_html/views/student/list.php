<?php /** @var array $students, int $page, int $pages, string $search */ ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>📚 Ученики</h2>
        <a href="index.php?entity=student&action=create" class="btn btn-primary">+ Добавить</a>
    </div>
    
    <!-- Поиск -->
    <form class="mb-3" method="get">
        <input type="hidden" name="entity" value="student">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Поиск по ФИО..." value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-outline-secondary" type="submit">Найти</button>
        </div>
    </form>
    
    <!-- Таблица -->
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-light">
                <tr>
                    <th>ID</th><th>Фамилия</th><th>Имя</th><th>Телефон</th><th>Email</th><th>Дата рождения</th><th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $s): ?>
                <tr>
                    <td><?= $s['student_id'] ?></td>
                    <td><?= htmlspecialchars($s['last_name']) ?></td>
                    <td><?= htmlspecialchars($s['first_name']) ?></td>
                    <td><?= htmlspecialchars($s['phone']) ?></td>
                    <td><?= htmlspecialchars($s['email']) ?></td>
                    <td><?= htmlspecialchars($s['birth_date']) ?></td>
                    <td>
                        <a href="index.php?entity=student&action=view&id=<?= $s['student_id'] ?>" class="btn btn-sm btn-info">👁</a>
                        <a href="index.php?entity=student&action=edit&id=<?= $s['student_id'] ?>" class="btn btn-sm btn-warning">✏️</a>
                        <a href="index.php?entity=student&action=delete&id=<?= $s['student_id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Удалить?')">🗑️</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Пагинация -->
    <?php if ($pages > 1): ?>
    <nav>
        <ul class="pagination">
            <?php for ($p = 1; $p <= $pages; $p++): ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="?entity=student&page=<?= $p ?>&search=<?= urlencode($search) ?>"><?= $p ?></a>
            </li>
            <?php endfor; ?>
        </ul>
    </nav>
    <?php endif; ?>
</div>