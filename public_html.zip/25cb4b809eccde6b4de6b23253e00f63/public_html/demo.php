<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'src/Database.php';
require_once 'src/RepositoryException.php';
require_once 'src/AbstractRepository.php';
require_once 'src/TeacherRepository.php';
require_once 'src/StudentRepository.php';
require_once 'src/LessonRepository.php';
require_once 'src/HomeworkRepository.php';

echo "<pre>";
try {
    $pdo = Database::getConnection();
    echo "✅ Подключение к БД установлено.\n\n";

    $teachers = new TeacherRepository($pdo);
    $students = new StudentRepository($pdo);
    $lessons  = new LessonRepository($pdo);
    $homework = new HomeworkRepository($pdo);

    // 1. Получить всех преподавателей
    echo "👨‍🏫 Все преподаватели:\n";
    print_r($teachers->findAll());

    // 2. Найти ученика по ID
    echo "\n Ученик ID=1:\n";
    print_r($students->findById(1));

    // 3. Создать урок с проверкой ограничений (транзакция)
    echo "\n📅 Создание нового урока...\n";
    $newLessonId = $lessons->createLessonWithValidation(2, 3, 3, '2026-06-01 15:00:00', 60);
    echo "✅ Урок создан, ID: $newLessonId\n";

    // 4. Обновить статус урока
    $lessons->update($newLessonId, ['status' => 'проведено']);
    echo "✅ Статус урока обновлён на 'проведено'.\n";

    // 5. Получить нагрузку преподавателя
    echo "\n📊 Нагрузка преподавателя ID=1 за неделю:\n";
    print_r($lessons->getTeacherLoad(1, '2026-05-15', '2026-05-25'));

    // 6. Удалить урок
    $lessons->delete($newLessonId);
    echo "✅ Урок ID=$newLessonId удалён.\n";

} catch (RepositoryException $e) {
    echo "❌ Ошибка репозитория: " . $e->getMessage() . "\n";
} catch (Exception $e) {
    echo "❌ Общая ошибка: " . $e->getMessage() . "\n";
}
echo "</pre>";
