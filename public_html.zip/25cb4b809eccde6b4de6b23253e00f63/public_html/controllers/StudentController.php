<?php
require_once __DIR__ . '/../src/Validator.php';
require_once __DIR__ . '/../src/StudentRepository.php';

class StudentController extends BaseController {
    private StudentRepository $repo;
    
    public function __construct(PDO $pdo) {
        parent::__construct($pdo);
        $this->repo = new StudentRepository($pdo);
    }
    
    public function list(): void {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = 10;
        $offset = ($page - 1) * $limit;
        $search = trim($_GET['search'] ?? '');
        
        $where = $search ? ['last_name' => "%$search%", 'first_name' => "%$search%"] : [];
        $students = $this->repo->findAllPaginated($limit, $offset, $where);
        $total = $this->repo->count($where);
        $pages = ceil($total / $limit);
        
        $this->render('student/list', [
            'students' => $students,
            'page' => $page,
            'pages' => $pages,
            'search' => $search
        ]);
    }
    
    public function create(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Validator::checkCsrfToken($_POST['csrf_token'] ?? '')) {
                Validator::setFlash('error', 'Ошибка токена CSRF');
                $this->redirect('index.php', ['entity' => 'student', 'action' => 'create']);
            }
            
            $errors = Validator::validateStudent($_POST);
            if ($errors) {
                $this->render('student/create', ['errors' => $errors, 'old' => $_POST]);
                return;
            }
            
            try {
                $this->repo->create([
                    'last_name' => $_POST['last_name'],
                    'first_name' => $_POST['first_name'],
                    'patronymic' => $_POST['patronymic'] ?? null,
                    'phone' => $_POST['phone'],
                    'email' => $_POST['email'],
                    'birth_date' => $_POST['birth_date'],
                    'enrollment_date' => $_POST['enrollment_date'] ?? date('Y-m-d')
                ]);
                Validator::setFlash('success', 'Ученик добавлен');
                $this->redirect('index.php', ['entity' => 'student']);
            } catch (Exception $e) {
                Validator::setFlash('error', 'Ошибка: ' . $e->getMessage());
                $this->render('student/create', ['old' => $_POST]);
            }
        } else {
            $this->render('student/create', ['csrf' => Validator::generateCsrfToken()]);
        }
    }
    
    public function edit(int $id): void {
        $student = $this->repo->findById($id);
        if (!$student) {
            Validator::setFlash('error', 'Ученик не найден');
            $this->redirect('index.php', ['entity' => 'student']);
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Validator::checkCsrfToken($_POST['csrf_token'] ?? '')) {
                Validator::setFlash('error', 'Ошибка токена CSRF');
                $this->redirect('index.php', ['entity' => 'student', 'action' => 'edit', 'id' => $id]);
            }
            
            $errors = Validator::validateStudent($_POST, true);
            if ($errors) {
                $this->render('student/edit', ['errors' => $errors, 'old' => $_POST, 'student' => $student]);
                return;
            }
            
            try {
                $this->repo->update($id, [
                    'last_name' => $_POST['last_name'],
                    'first_name' => $_POST['first_name'],
                    'patronymic' => $_POST['patronymic'] ?? null,
                    'phone' => $_POST['phone'],
                    'email' => $_POST['email'],
                    'birth_date' => $_POST['birth_date']
                ]);
                Validator::setFlash('success', 'Данные обновлены');
                $this->redirect('index.php', ['entity' => 'student']);
            } catch (Exception $e) {
                Validator::setFlash('error', 'Ошибка: ' . $e->getMessage());
                $this->render('student/edit', ['old' => $_POST, 'student' => $student]);
            }
        } else {
            $this->render('student/edit', [
                'student' => $student,
                'csrf' => Validator::generateCsrfToken()
            ]);
        }
    }
    
    public function delete(int $id): void {
        $student = $this->repo->findById($id);
        if (!$student) {
            Validator::setFlash('error', 'Ученик не найден');
            $this->redirect('index.php', ['entity' => 'student']);
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!Validator::checkCsrfToken($_POST['csrf_token'] ?? '')) {
                Validator::setFlash('error', 'Ошибка токена CSRF');
                $this->redirect('index.php', ['entity' => 'student']);
            }
            
            // Проверка связей: есть ли уроки у этого ученика?
            $hasLessons = $this->repo->hasRelatedLessons($id);
            if ($hasLessons) {
                Validator::setFlash('error', 'Нельзя удалить: у ученика есть записанные уроки');
                $this->redirect('index.php', ['entity' => 'student']);
            }
            
            try {
                $this->repo->delete($id);
                Validator::setFlash('success', 'Ученик удалён');
            } catch (Exception $e) {
                Validator::setFlash('error', 'Ошибка удаления: ' . $e->getMessage());
            }
            $this->redirect('index.php', ['entity' => 'student']);
        } else {
            $this->render('student/delete', [
                'student' => $student,
                'csrf' => Validator::generateCsrfToken()
            ]);
        }
    }
    
    // 🔹 Для партнёра: детальная карточка ученика
    public function view(int $id): void {
        $student = $this->repo->findById($id);
        if (!$student) {
            Validator::setFlash('error', 'Ученик не найден');
            $this->redirect('index.php', ['entity' => 'student']);
        }
        
        // Подсчёт связанных уроков
        $lessonsCount = $this->repo->getLessonsCount($id);
        
        $this->render('student/view', [
            'student' => $student,
            'lessonsCount' => $lessonsCount
        ]);
    }
}