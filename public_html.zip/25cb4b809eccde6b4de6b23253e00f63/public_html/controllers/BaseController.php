<?php
abstract class BaseController {
    protected PDO $pdo;
    
    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }
    
    protected function redirect(string $url, array $params = []): void {
        if ($params) $url .= '?' . http_build_query($params);
        header("Location: $url");
        exit;
    }
    
    protected function render(string $view, array $data = []): void {
        extract($data, EXTR_SKIP);
        require __DIR__ . '/../views/layout.php';
    }
    
    protected function requireAuth(): void {
        // Заглушка: в реальной системе — проверка сессии пользователя
    }
}